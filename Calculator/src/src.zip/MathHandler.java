public class MathHandler {

    public static double add(double x, double y){
        return x+y;
    }

    public static int add(int x, int y){
        return x + y;
    }

    public static double subtract(double x, double y){
        return x-y;
    }

    public static int subtract(int x, int y){
        return x - y;
    }

    public static double divide(double x, double y){
        return x/y;
    }

    public static double divide(int x, int y){
        return x/ (double) y;
    }

    public static double multiply(double x, double y){
        return x*y;
    }

    public static int multiply(int x, int y){
        return x*y;
    }


}
